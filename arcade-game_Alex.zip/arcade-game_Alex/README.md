# Classic Arcade Game (aka "frogger")

# Goal

The player must get to the other side of the game board (to the sea) without hitting any bugs

# Instructions (how to play)

- It's pretty simple - use the arrow keys on your keyboard to maneuver the character around the board

- Avoid the bugs at all costs

- Score and points are displayed for your convenience

// Sources

https://developer.mozilla.org/en-US/docs/Web/JavaScript

https://github.com/

https://stackoverflow.com/

- Audio files used:
  http://www.thanatosrealms.com/war2/sounds/humans/buildings/shipyard.wav
  http://www.fright-bytes.com/spooky-sound-files/spooky-wavs/headchop.wav
  http://www.mario-museum.net/sons/smb_gameover.wav
